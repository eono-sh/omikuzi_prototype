package com.websarva.wings.android.myapplication3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.style.TtsSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.BreakIterator;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btClick1 = findViewById(R.id.btClick1);
        HelloListener Listener = new HelloListener();
        View.OnClickListener listener;
        btClick1.setOnClickListener(Listener);
    }
    private class HelloListener implements View.OnClickListener{
        @Override
        public void onClick(View view){
            int id = view.getId();
            switch(id){
                case R.id.btClick1:
                    String kuji = "大吉,中吉,吉,凶,大凶";
                    String[] atari = kuji.split(",");
                    double rand = Math.random()* atari.length;
                    int num = (int)rand;

                    TextView kekka=findViewById((R.id.result1));
                    kekka.setText(atari[num]);
            }
        }
    }
}